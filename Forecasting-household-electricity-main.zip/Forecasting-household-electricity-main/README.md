# Forecasting-household-electricity
A project about time series forecasting with a LSTM based model.
